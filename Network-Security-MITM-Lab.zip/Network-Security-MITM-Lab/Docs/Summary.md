**##Network Security MITM Attack Simulation Lab**



1. **Overview**



This academic project demonstrates practical network security attacks within an isolated virtual environment.



The project investigates:



\- ARP Spoofing

\- DNS Spoofing

\- Network Eavesdropping

\- Credential Capture

\- Man-in-the-Middle (MITM) Attacks



**2. Technologies Used**



\- Kali Linux

\- Windows 10

\- VirtualBox

\- Wireshark

\- Ettercap

\- arpspoof



**3. Lab Architecture**



Victim Machine (Windows 10)

&#x20;       |

&#x20;       |

Kali Linux (MITM Attacker)

&#x20;       |

&#x20;       |

Virtual Gateway





**##Demonstrations**



1. **ARP Spoofing**



Successfully poisoned victim ARP cache.



!\[ARP Spoofing](screenshots/arp-spoofing.png)



**2. Credential Capture**



Captured HTTP POST credentials using Wireshark.



!\[Wireshark](screenshots/wireshark-capture.png)



**3. DNS Spoofing**



Redirected victim traffic to attacker-controlled page.



!\[DNS Spoofing](screenshots/dns-spoofing.png)



**##** **Skills Demonstrated**



\- Cyber Security Fundamentals

\- Network Security

\- Packet Analysis

\- Traffic Monitoring

\- Wireshark Analysis

\- MITM Techniques

\- Virtual Lab Design



**## Ethical Statement**



All demonstrations were conducted in a fully isolated VirtualBox Host-Only environment for educational and defensive security purposes.



**## Report**



Full project report available:



\[Network-Security-MITM-Lab](report/Spoofing\_Eavesdropping\_Report.pdf)



**## Author - Hemant Raaz Sah**



Group Leader - CC5009NI Cyber Security in Computing

