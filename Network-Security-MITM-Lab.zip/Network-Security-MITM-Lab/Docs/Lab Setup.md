**###Lab Setup**



**# Attacker Machine**



\- Kali Linux

\- IP: 192.168.232.128



**# Victim Machine**



\- Windows 10

\- IP: 192.168.232.129



**# Network**



\- VirtualBox Host-Only Adapter

\- Isolated from external networks



**# Tools**



\- Wireshark

\- Ettercap

\- arpspoof

