**###Lessons Learned**



During this project I learned:



\- How ARP spoofing enables MITM attacks.

\- Why HTTP traffic can expose credentials in plaintext.

\- How DNS spoofing can redirect users to malicious websites.

\- The importance of HTTPS, DNSSEC and network monitoring.

\- Practical use of Kali Linux security tools.

